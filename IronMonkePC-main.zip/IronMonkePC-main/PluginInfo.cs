﻿
namespace IronMonke
{
    class PluginInfo
    {
        public const string GUID = "com.buzzbzzzbzzbzzzthe18th.gorillatag.ironmonkepc";
        public const string Name = "IronMonke";
        public const string Version = "1.0.0";
    }
}
